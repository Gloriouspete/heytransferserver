import mysql from 'mysql2/promise';

class Database {
    static pool = mysql.createPool({
        host: 'localhost',
        user: 'root',
        password: '',
        database: 'fileupload',
        waitForConnections: true,
        connectionLimit: 20,
        queueLimit: 0,
    });

    static async executeQuery(query, params) {
        const db = await Database.pool.getConnection();
        try {
            const [result, fields] = await db.execute(query, params);
            return result;
        } catch (error) {
            console.error('Error executing query:', error.message);
            throw error;
        } finally {
            db.release();
        }
    }
}

export default Database;
